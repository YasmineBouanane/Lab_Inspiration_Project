﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace Lab_Project3
{
    public partial class MainWindow : Window
    {
        // For managing OTP (generation and simple storage)
        private string generatedOTP;

        public MainWindow()
        {
            InitializeComponent();
        }

        // Method to generate a random OTP
        private string GenerateOTP()
        {
            Random random = new Random();
            return random.Next(100000, 999999).ToString();
        }

        // Method to send the OTP by email (replace with a real email service in a real application)
        private void SendOTPEmail(string email, string otp)
        {
            // This method simulates sending an email (replace with MailKit or another service)
            MessageBox.Show($"An OTP has been sent to {email}. The code is: {otp}", "OTP Sent", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // Method to simulate OTP verification
        private bool VerifyOTP(string enteredOTP)
        {
            return enteredOTP == generatedOTP;
        }

        // Login method
        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text;
            string password = PasswordBox.Password;

            // Simulate a database or service call to check credentials
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                StatusTextBlock.Text = "Email and password are required.";
                return;
            }

            // Generate OTP and send email for 2FA
            generatedOTP = GenerateOTP();
            SendOTPEmail(email, generatedOTP);

            // Prompt the user to enter the OTP
            StatusTextBlock.Text = "Enter the OTP code you received.";
            SubmitButton.Content = "Verify OTP";
            SubmitButton.Click -= SubmitButton_Click;
            SubmitButton.Click += VerifyOTPButton_Click;
        }

        // Method to verify OTP during login
        private void VerifyOTPButton_Click(object sender, RoutedEventArgs e)
        {
            string enteredOTP = Microsoft.VisualBasic.Interaction.InputBox("Enter your OTP", "OTP Verification");

            if (VerifyOTP(enteredOTP))
            {
                StatusTextBlock.Text = "Login successful!";
                SubmitButton.Content = "Log In";
                SubmitButton.Click -= VerifyOTPButton_Click;
                SubmitButton.Click += SubmitButton_Click;
            }
            else
            {
                StatusTextBlock.Text = "Incorrect OTP. Please try again.";
            }
        }

        // Registration method (you can implement user registration logic here)
        private void SignUpButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text;
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                StatusTextBlock.Text = "Email and password are required for registration.";
                return;
            }

            // For this example, we generate an OTP to validate the registration
            generatedOTP = GenerateOTP();
            SendOTPEmail(email, generatedOTP);

            // Ask user to enter OTP to confirm registration
            StatusTextBlock.Text = "Enter the OTP code to confirm your registration.";
            SubmitButton.Content = "Confirm OTP";
            SubmitButton.Click -= SubmitButton_Click;
            SubmitButton.Click += ConfirmSignUpButton_Click;
        }

        // Method to confirm registration after OTP
        private void ConfirmSignUpButton_Click(object sender, RoutedEventArgs e)
        {
            string enteredOTP = Microsoft.VisualBasic.Interaction.InputBox("Enter your OTP", "OTP Verification");

            if (VerifyOTP(enteredOTP))
            {
                StatusTextBlock.Text = "Registration successful!";
                SubmitButton.Content = "Log In";
                SubmitButton.Click -= ConfirmSignUpButton_Click;
                SubmitButton.Click += SubmitButton_Click;
            }
            else
            {
                StatusTextBlock.Text = "Incorrect OTP. Please try again.";
            }
        }
    }
}
